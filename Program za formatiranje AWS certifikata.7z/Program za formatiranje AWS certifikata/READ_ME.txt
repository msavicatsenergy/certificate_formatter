/**
 * ---OPIS---
 * Ovaj program moze da se koristi za bilo koji text fajl, ali je namenjen za AWS root certificate.
 * Program je za Windows OS.
 * Za spustanje se koristi terminal. 
 * 
 * ---KORISCENJE---
 * Fajl sa certifikatom stavi se u isti folder kao sto je format_certifikat.exe i deklaracija imena 
 * moze se uraditi na sledece nacine (od najlaksek po najtezi):
 * 
 * 1) Ukuca se ime na terminal. 
 *      Za ovu opciju je neophodno da NIJE definisano IME_FAJLA_SA_CERTIFIKATOM:
 * === #define IME_FAJLA_SA_CERTIFIKATOM "(ime input fajla)"
 * 
 * 2) Preko terminala se kao prvi argument ukuca ime fajla.
 *      Ova opcija ne ovisi of definicije IME_FAJLA_SA_CERTIFIKATOM. 
 *      Posle ukucanja ili copy-paste-a spusta se sa enterom:
 * === .\format_text [ime input fajla]
 *      
 *      naprimer:
 * 
 * === C:\vscode_projects\format_certificate>\.format_text 0b0d750052a4073ce360359044713d597cc50d90f2efb414cbd788ac9a530a6b-public.pem
 * === PROGRAM START
 * === ...
 *      
 * 3) Hardcode. IME_FAJLA_SA_CERTIFIKATOM mora biti definisano i stavi se ime falja.
 *      Za kompilaciju:
 *      gcc -Wall -Werror .\format_text.c -o format_text
 *      Samo se spusti format_text.exe ili klikom, ili u terminalu:
 * === .\format_text
 * 
 * 
 */